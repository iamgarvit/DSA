#include <bits/stdc++.h>
using namespace std;


int main(){
    float temp_cel;
    cout<<"Enter temperature in celcius : ";
    cin>>temp_cel;
    cout<<"Temperature in fahrenheit is : "<< ((9*temp_cel)/5)+32<<"\n";
    return 0;
}