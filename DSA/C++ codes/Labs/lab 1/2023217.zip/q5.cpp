#include <bits/stdc++.h>
using namespace std;

int main(){
    cout<<"My name is Garvit. \nMy age is 19 years. \nI live in Dwarka,Delhi. \nAbout me: I'm very interested in AI and it's impact on the world. \n";
}