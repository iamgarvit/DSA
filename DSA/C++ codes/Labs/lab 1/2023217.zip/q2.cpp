#include <bits/stdc++.h>
using namespace std;
int main(){
    string name,address;
    int age;
    cout<<"Enter your name : ";
    cin>>name;
    cout<<"Enter your address : ";
    cin>>address;
    cout<<"Enter your age : ";
    cin>>age;
    cout<<"Your name is : "<<name<<"\n"<<"Your address is : "<<address<<"\n"<<"Your age is : "<<age;
    return 0;
}