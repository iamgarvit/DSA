#include <bits/stdc++.h>
using namespace std;
int main(){
    float a,b;
    float avg;
    cin>>a;
    cin>>b;
    avg=(a+b)/2;
    cout<<"The sum is : "<<a+b<<"\n";
    cout<<"The average is : "<<avg<<"\n";
    cout<<"The sum of squares is : "<<(a*a + b*b)<<"\n";
    return 0;
}