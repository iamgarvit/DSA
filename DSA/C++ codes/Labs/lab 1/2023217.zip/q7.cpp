#include <bits/stdc++.h>
using namespace std;

int main(){
    float radius,area,pi=3.14159;
    cin>>radius;
    area=radius*radius*pi;
    cout<<"The area of a circle of radius "<<radius<<" units is "<<area<<" units";
}